import React from "react";
import logo from "./logo.svg";
import "./App.css";
import Alert from "react-bootstrap/Alert";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Stack from "./pages/stack";

function App() {
  return (
    <Container fluid className="main-container">
      <Alert dismissible variant="danger">
        <Alert.Heading>Oh snap! You got an error!</Alert.Heading>
        <p>Change this and that and try again.</p>
      </Alert>
      <Row>
        <Col className="color-col">1 of 2</Col>
        <Col className="color-col">2 of 2</Col>
      </Row>
      <Row>
        <Col className="color-col">1 of 3</Col>
        <Col xs={6} className="color-col">
          2 of 3
        </Col>
        <Col className="color-col">3 of 3</Col>
      </Row>
      <Row className="mt-2">
        <Stack />
      </Row>
    </Container>
  );
}

export default App;
