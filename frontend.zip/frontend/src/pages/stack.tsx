import Stack from 'react-bootstrap/Stack';

function VerticalExample() {
  return (
    <Stack gap={3} direction='horizontal' className='menu mx-auto col-md-5'>
      <div className="p-2 menu-item">First item</div>
      <div className="p-2 menu-item">Second item</div>
      <div className="p-2 menu-item">Third item</div>
    </Stack>
  );
}

export default VerticalExample;